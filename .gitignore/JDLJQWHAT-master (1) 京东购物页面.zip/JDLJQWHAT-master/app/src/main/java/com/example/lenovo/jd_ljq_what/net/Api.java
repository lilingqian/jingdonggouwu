package com.example.lenovo.jd_ljq_what.net;

public interface Api {
    String BASEURL = "https://www.zhaoapi.cn/";
}
