package com.example.lenovo.jd_ljq_what.inter;

public interface OnItemClickListener {
    void onItemClick(int position);

    void onLongItemClick(int position);
}
