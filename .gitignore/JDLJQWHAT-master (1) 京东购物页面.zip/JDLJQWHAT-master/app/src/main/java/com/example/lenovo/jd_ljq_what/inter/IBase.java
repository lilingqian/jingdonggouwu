package com.example.lenovo.jd_ljq_what.inter;

import android.view.View;

public interface IBase {
    int getContentLayout();

    void inject();

    void initView(View view);
}
